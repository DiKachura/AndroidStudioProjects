package com.example.myapplication2009

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ChangedPackages
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.TextView

const val EXTRA_ANSWER_SHOWN="com.example.My Application2009.answer_show"
const val EXTRA_ANSWER_IS_TRUE="com.example.My Application2009.answer_is_true"
class CheatActivity : AppCompatActivity() {
    private lateinit var showAnswerButton: Button
    private lateinit var answerTextView: TextView
    private var answerIsTrue= false
    companion object{
        fun newIntent(packageContext: Context, answerIsTrue:Boolean):Intent{
            return Intent(packageContext,CheatActivity::class.java).apply{
                putExtra(EXTRA_ANSWER_IS_TRUE,answerIsTrue)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        answerIsTrue=intent?.getBooleanExtra(EXTRA_ANSWER_IS_TRUE,false)?:false
        setContentView(R.layout.activity_cheat)
        showAnswerButton=findViewById(R.id.btnShow)
        answerTextView=findViewById(R.id.tvAnswer)
        showAnswerButton.setOnClickListener {
            val s = if(answerIsTrue)"Да" else "Нет"
            answerTextView.text=s
            answerTextView.visibility= View.VISIBLE
            setAnswerShowResult(true)
        }
    }
    private fun setAnswerShowResult(isAnswerShown: Boolean=false)
    {
        val data= Intent().apply{
            putExtra(EXTRA_ANSWER_SHOWN,isAnswerShown)
    }
        setResult(Activity.RESULT_OK,data)
    }
}